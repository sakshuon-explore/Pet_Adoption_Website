document.getElementById("submitBtn").addEventListener('submit', btnClick);

function btnClick() {
  alert ("Thank you for saving a life by adopting!");
}